let img1, img2, img3;

function preload() {
  img1 = loadImage('image1.jpg');
  img2 = loadImage('image2.jpg');
  img3 = loadImage('image3.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  // choose a system font and apply it to text
  textFont("Arial");
  
  // change stroke and fill for text
  stroke(255, 0, 0);
  fill(0, 255, 0);
  
  // create text with width and height measurements
  let myText = "Hello!";
  let textWidth = 200;
  let textHeight = 100;
  
  textSize(32);
  textAlign(CENTER, CENTER);
  text(myText, width/2, height/2, textWidth, textHeight);
  
  image(img1, mouseX, mouseY);
  image(img2, width/2, height/2, mouseX, mouseY);
  image(img3, mouseX, mouseY);
}