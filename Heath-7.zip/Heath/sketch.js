var farenheitTemp = 35;
var cloudX = 100;
var cloudY = 100;

function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255);
  angleMode(DEGREES);
  background(140, 190, 214);

  var celciusTemp = calculateCelcius(farenheitTemp);
  print(celciusTemp);
}

function makeClouds(cloudX, cloudY) {
  fill(250);
  noStroke();
  ellipse(cloudX, cloudY, 70, 50);
  ellipse(cloudX + 10, cloudY + 10, 70, 50);
  ellipse(cloudX - 20, cloudY + 10, 70, 50);
  translate(50, 0);
}

function draw() {
  // Use scale() method to update drawing
  scale(1.2, 1);
  
  // Create multiple clouds using a for loop
  for (var i = 0; i < 4; i++) {
    makeClouds(cloudX + i * 100, cloudY - 50);
  }

  fill(240);
  rect(-200, 300, 400);
  
  push();
  translate(6, 106);
  rotate(PI/4);
  ellipse(0, 0, 15, 15);
  pop();

  ellipse(76, 106, 15, 15);
  ellipse(36, 106, 15, 15);
}

function calculateCelcius(t) {
  var newTemp = (t - 32) * 5/9;
  return newTemp;
}