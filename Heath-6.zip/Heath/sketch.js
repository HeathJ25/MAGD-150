var num = 100;
var x_pos = [];
var y_pos = [];
var white_dots = [];

function setup() {
	createCanvas(400, 400);
	colorMode(RGB, 255);
	noStroke();
	for (var i = 0; i < num; i++) {
		x_pos[i] = 0;
		y_pos[i] = 0;
	}
	for (i = 0; i < 100; i++) {
		white_dots.push({
			x: random(width),
			y: random(height)
		});
	}
  // Determine the length of the white_dots array and print it to the console
  print("The length of the white_dots array is: " + white_dots.length);
  print("The length of the x_pos array is: " + x_pos.length);
  print("The length of the y_pos array is: " + y_pos.length);
}

function draw() {
	background(0);
  
    //Does the math required to draw the white dots
	for (var i = 0; i < white_dots.length; i++) {
		white_dots[i].x += random(-1, 1);
		white_dots[i].y += random(-1, 1);
		white_dots[i].x = (white_dots[i].x + width) % width;
		white_dots[i].y = (white_dots[i].y + height) % height;
		fill(255);
		ellipse(white_dots[i].x, white_dots[i].y, 2, 2);
	}

	for (i = num - 1; i > 0; i--) {
		x_pos[i] = x_pos[i-1];
		y_pos[i] = y_pos[i-1];
	}
	x_pos[0] = mouseX;
	y_pos[0] = mouseY;
	for (i = 0; i < num; i++) {
		fill(255, 255, 0);
		arc(x_pos[i], y_pos[i], 40, 40, 0.52, 5.76);
      //Creates the arc meant to look like Pac-Man, the retro game character
	}
}